/*========================= typing amation =========================*/
var typed = new Typed(".typing",{
    strings:[" ","Web Designer","web Developer","Graphic Designer","M Jay "],
    typedSpeed:100,
    BackSpeed:50,
    loop: true
})